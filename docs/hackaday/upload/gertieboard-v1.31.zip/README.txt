Gertieboard v1.31 - FPGA chipset + BIOS
=======================================
https://github.com/mathijsvandenberg/gertieboard

Two things are needed, and they are separate:
  * the FPGA bitstream = the chipset
  * gertieboard_bios.64k = the BIOS that runs on it
Updating one does not update the other.

Bitstream containers - same design, different programmer:
  gertieboard.sof   Quartus (quartus_pgm)          this session only
  gertieboard.jic   Quartus, via JTAG to the flash  persists
  gertieboard.rbf   openFPGALoader (mac/Linux)      this session only
  gertieboard.rpd   openFPGALoader, to the flash    persists

  openFPGALoader -c usb-blaster gertieboard.rbf
  openFPGALoader -c usb-blaster -f --file-type rpd gertieboard.rpd

Target: Terasic DE0-Nano, Cyclone IV E EP4CE22F17C6, stock and unmodified.
The BIOS goes onto the top board's SPI flash (BIOSFLASH from DOS), or is
served over the serial link by GertieBoardLoader during development.

Checksums are in SHA256SUMS. MIT licensed; no warranty of any kind.
